﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MenuProgramEB
{
    class ClassGlobals
    {
        public static int ORDER_NUM = 1;
        public static int ORDER_ID = 1;
        public static string RunningPath = AppDomain.CurrentDomain.BaseDirectory;
    }
}
