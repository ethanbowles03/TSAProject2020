﻿namespace MenuProgramEB
{
    partial class ViewMyOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.customerNameBox = new System.Windows.Forms.TextBox();
            this.dateBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.timeBox = new System.Windows.Forms.TextBox();
            this.tinmeLabel = new System.Windows.Forms.Label();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.finishOrder = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, -1);
            this.panel1.Margin = new System.Windows.Forms.Padding(1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(785, 56);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F);
            this.label1.Location = new System.Drawing.Point(222, 5);
            this.label1.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(334, 46);
            this.label1.TabIndex = 0;
            this.label1.Text = "Student Selection";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(19, 84);
            this.label2.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(195, 31);
            this.label2.TabIndex = 1;
            this.label2.Text = "Student Name:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // customerNameBox
            // 
            this.customerNameBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.customerNameBox.Location = new System.Drawing.Point(230, 89);
            this.customerNameBox.Margin = new System.Windows.Forms.Padding(1);
            this.customerNameBox.Name = "customerNameBox";
            this.customerNameBox.Size = new System.Drawing.Size(238, 30);
            this.customerNameBox.TabIndex = 2;
            // 
            // dateBox
            // 
            this.dateBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.dateBox.Location = new System.Drawing.Point(230, 150);
            this.dateBox.Margin = new System.Windows.Forms.Padding(1);
            this.dateBox.Name = "dateBox";
            this.dateBox.Size = new System.Drawing.Size(238, 30);
            this.dateBox.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(32, 145);
            this.label3.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(177, 31);
            this.label3.TabIndex = 3;
            this.label3.Text = "Todays Date:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // timeBox
            // 
            this.timeBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.timeBox.Location = new System.Drawing.Point(230, 211);
            this.timeBox.Margin = new System.Windows.Forms.Padding(1);
            this.timeBox.Name = "timeBox";
            this.timeBox.Size = new System.Drawing.Size(238, 30);
            this.timeBox.TabIndex = 6;
            // 
            // tinmeLabel
            // 
            this.tinmeLabel.AutoSize = true;
            this.tinmeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.tinmeLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tinmeLabel.Location = new System.Drawing.Point(28, 206);
            this.tinmeLabel.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.tinmeLabel.Name = "tinmeLabel";
            this.tinmeLabel.Size = new System.Drawing.Size(180, 31);
            this.tinmeLabel.TabIndex = 5;
            this.tinmeLabel.Text = "Current Time:";
            this.tinmeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(9, 262);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(1);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(756, 293);
            this.flowLayoutPanel1.TabIndex = 7;
            // 
            // finishOrder
            // 
            this.finishOrder.BackColor = System.Drawing.Color.White;
            this.finishOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.finishOrder.Location = new System.Drawing.Point(572, 121);
            this.finishOrder.Margin = new System.Windows.Forms.Padding(1);
            this.finishOrder.Name = "finishOrder";
            this.finishOrder.Size = new System.Drawing.Size(128, 80);
            this.finishOrder.TabIndex = 8;
            this.finishOrder.Text = "FINISH";
            this.finishOrder.UseVisualStyleBackColor = false;
            this.finishOrder.Click += new System.EventHandler(this.finishOrder_Click);
            // 
            // ViewMyOrder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.ClientSize = new System.Drawing.Size(778, 582);
            this.Controls.Add(this.finishOrder);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.timeBox);
            this.Controls.Add(this.tinmeLabel);
            this.Controls.Add(this.dateBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.customerNameBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(1);
            this.MaximumSize = new System.Drawing.Size(794, 621);
            this.MinimumSize = new System.Drawing.Size(794, 621);
            this.Name = "ViewMyOrder";
            this.Text = "MyOrder";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox customerNameBox;
        private System.Windows.Forms.TextBox dateBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox timeBox;
        private System.Windows.Forms.Label tinmeLabel;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Button finishOrder;
    }
}